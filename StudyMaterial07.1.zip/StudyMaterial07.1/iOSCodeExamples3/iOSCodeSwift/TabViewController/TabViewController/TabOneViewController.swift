//
//  TabOneViewController.swift
//  TabViewController
//
//  Created by Amarjit Singh on 31/05/24.
//

//import Foundation

import UIKit

class TabOneViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Set the view's background color to blue
        self.view.backgroundColor = UIColor.orange
        // Set the title for the tab
        self.title = "Tab 01"
    }
}
