
package learnJava;

public class Experiments {
	public static void playWithNullables() {
		String greeting = new String("Hello World!");
		greeting = null;
		System.out.println( greeting );

		// String greetingUpper = greeting.toUpperCase();
		String greetingUpper;
		// if ( greeting != null ) 
		greetingUpper = greeting.toUpperCase();
		// Exception in thread "main" java.lang.NullPointerException: 
		System.out.println( greetingUpper );
	}

	public static void playWithEqality() {
		String greeting = new String("Hello");
		String hello = new String("Hello");

		if ( greeting == hello ) {
			System.out.println( "Hello World" );
		} else {
			System.out.println( "It's Not My World" );
		}
	}

	public static void main( String[] args ) {
		// System.out.println("\n\nFunction: playWithNullables");
		// playWithNullables();

		System.out.println("\n\nFunction: playWithEqality");
		playWithEqality();

		// System.out.println("\n\nFunction: ");
		// System.out.println("\n\nFunction: ");
		// System.out.println("\n\nFunction: ");
		// System.out.println("\n\nFunction: ");

	}
}
