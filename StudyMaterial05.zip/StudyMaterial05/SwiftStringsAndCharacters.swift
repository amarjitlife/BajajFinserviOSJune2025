//____________________________________________________________________________

let emptyString = ""
let anotherEmptyString = String()

if emptyString.isEmpty {
	print("Empty String")
} else {
	print("Non Empty String")	
}

if anotherEmptyString.isEmpty {
	print("Empty String")
} else {
	print("Non Empty String")	
}


var someString = "Hello, "
let world = "World"

someString = someString + world
print( someString )

for c in someString {
	print( c )
}

let dogcow = "🐶🐮"
print( dogcow )

for character in dogcow {
	print( character )
}

let koreanHello = "안녕하세요"
print( koreanHello )

for character in koreanHello {
	print( character )
}

//____________________________________________________________________________

let dog: Character = "🐶"
print( dog )

let animalsCharacters: [Character] = ["🐶", "🐮", "🐈", "🐱"]
for a in animalsCharacters {
	print( a )
}

var animalsString = String( animalsCharacters ) 
print( animalsString )

let exclamation: Character = "!"
animalsString.append( exclamation )
print( animalsString )

//____________________________________________________________________________
// Unicode Points

let wiseWords = "\"Imagination is more important than knowledge\" - Einstein"
// "Imagination is more important than knowledge" - Einstein
let dollarSign = "\u{24}"           // $,  Unicode scalar U+0024
let blackHeart = "\u{2665}"         // ♥,  Unicode scalar U+2665
let sparklingHeart = "\u{1F496}"    // 💖, Unicode scalar U+1F496

print( dollarSign )
print( blackHeart )
print( sparklingHeart )

//____________________________________________________________________________

let eAcute: Character = "\u{E9}"                // é
let combinedEAcute: Character = "\u{65}\u{301}" // e followed by ́

print( eAcute )
print( combinedEAcute )

print( eAcute == combinedEAcute )


//____________________________________________________________________________


// "Voulez-vous un café?" using LATIN SMALL LETTER E WITH ACUTE
let eAcuteQuestion = "Voulez-vous un caf\u{E9}?"

// "Voulez-vous un café?" using LATIN SMALL LETTER E and COMBINING ACUTE ACCENT
let combinedEAcuteQuestion = "Voulez-vous un caf\u{65}\u{301}?"
let combinedEAcuteQuestion2 = "Voulez-vous un cafe\u{301}?"

print( eAcuteQuestion )
print( combinedEAcuteQuestion )
print( combinedEAcuteQuestion2 )

if ( eAcuteQuestion == combinedEAcuteQuestion ) {
	print("Strings Equal i.e. Same")
} else {
	print("Strings UNEqual i.e. Not Same")	
}

if ( eAcuteQuestion == combinedEAcuteQuestion2 ) {
	print("Strings Equal i.e. Same")
} else {
	print("Strings UNEqual i.e. Not Same")	
}

//____________________________________________________________________________

let latinCapitalLeterA: Character = "\u{41}"
let cyrillicCapitalLetterA: Character = "\u{0410}"

print( latinCapitalLeterA )
print( cyrillicCapitalLetterA )

if ( latinCapitalLeterA == cyrillicCapitalLetterA ) {
	print("Character Equal i.e. Same")
} else {
	print("Character UNEqual i.e. Not Same")	
}

//____________________________________________________________________________

// Prefix and Suffix Equality
let romeoAndJuliet = [
    "Act 1 Scene 1: Verona, A public place",
    "Act 1 Scene 2: Capulet's mansion",
    "Act 1 Scene 3: A room in Capulet's mansion",
    "Act 1 Scene 4: A street outside Capulet's mansion",
    "Act 1 Scene 5: The Great Hall in Capulet's mansion",
    "Act 2 Scene 1: Outside Capulet's mansion",
    "Act 2 Scene 2: Capulet's orchard",
    "Act 2 Scene 3: Outside Friar Lawrence's cell",
    "Act 2 Scene 4: A street in Verona",
    "Act 2 Scene 5: Capulet's mansion",
    "Act 2 Scene 6: Friar Lawrence's cell"
]
var act1SceneCount = 0

for scene in romeoAndJuliet {
    if scene.hasPrefix("Act 1") {
        act1SceneCount += 1
    }
}
print("There are \(act1SceneCount) scenes in Act 1")

var mansionCount = 0
var cellCount = 0
for scene in romeoAndJuliet {
    if scene.hasSuffix("Capulet's mansion") {
        mansionCount += 1
    } else if scene.hasSuffix("Friar Lawrence's cell") {
        cellCount += 1
    }
}
print("\(mansionCount) mansion scenes; \(cellCount) cell scenes")

//____________________________________________________________________________

// Unicode Representations of Strings
let dogString = "Dog!!🐶"

// UTF-8 Representation
for codeUnit in dogString.utf8 {
    print("\(codeUnit) ", terminator: "")
}
print("")

for codeUnit in dogString.utf16 {
    print("\(codeUnit) ", terminator: "")
}
print("")

// Unicode Scalar Representation
for scalar in dogString.unicodeScalars {
    print("\(scalar.value) ", terminator: "")
}
print("")

for scalar in dogString.unicodeScalars {
    print("\(scalar)")
}

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

