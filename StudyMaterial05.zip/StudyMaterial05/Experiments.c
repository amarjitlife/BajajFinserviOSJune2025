
#include <stdio.h>

//____________________________________________________________________________

void playWithTypesValues() {
	// let twoThousand: UInt16 = 2_000
	// let one: UInt8 = 1

	unsigned short twoThousand = 2000;
	unsigned char one = 1;

	// let twoThousandAndOne = twoThousand + one 
	unsigned short twoThousandAndOne = twoThousand + one;
	printf( "\nValue: %d", twoThousandAndOne );

	unsigned short maxValue = 65535;
	unsigned short maxValueAndOne = maxValue + one;
	printf( "\nValue: %d", maxValueAndOne );
}

//____________________________________________________________________________

void playWithIf() {

	int i = -10;

	if ( i ) {
		printf("\nValue: %d", i );
	} else {
		printf("\nSomething Else ...");
	}

}

//____________________________________________________________________________

void swapValue( int a, int b ) {
	int temp = a;
	a = b;
	b = temp;
} 

void swapValueAgain( int * a, int * b ) {
	int temp = *a;
	*a = *b;
	*b = temp;
} 

void playWithSwapping() {
	int aa = 100, bb = 200;
	printf("\nValues: %d %d", aa, bb );
	swapValue(aa, bb);
	printf("\nValues: %d %d", aa, bb );

	swapValueAgain(&aa, &bb);
	printf("\nValues: %d %d", aa, bb );

}

//____________________________________________________________________________

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
} Human ;

void doBhangra() { printf("\nDoing Bhangra"); }
void doHipHop() { printf("\nDoing HipHop"); }


void playWithHuman() {
	Human gabbar = { 420, "Gabbar Singh", doBhangra };
	printf("\nID 	: %d", gabbar.id );
	printf("\nName 	: %s", gabbar.name );
	gabbar.dance();

	Human basanti = { 100, "Basanti", doHipHop };
	printf("\nID 	: %d", basanti.id );
	printf("\nName 	: %s", basanti.name );
	basanti.dance();
}


//____________________________________________________________________________

int sum(int x, int y) { return x + y; }
int sub(int x, int y) { return x - y; }

int calculator( int x, int y, int (*operation)(int, int) ) {
	return operation(x , y);
}

void playWithCalculator() {
	int a = 200, b = 100;
	int result = 0;

	result = calculator( a, b, sum );
	printf("\nResult : %d", result );

	result = calculator( a, b, sub );
	printf("\nResult : %d", result );
}


//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

int main() {
	printf("\n\nFunction : playWithTypesValues");
	playWithTypesValues();

	printf("\n\nFunction : playWithIf");
	playWithIf();

	printf("\n\nFunction : playWithSwapping");
	playWithSwapping();

	printf("\n\nFunction : playWithHuman");
	playWithHuman();

	printf("\n\nFunction : playWithCalculator");
	playWithCalculator();
	
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
}
