
//____________________________________________________________________________
// Overloading Subscript Operator

// Instance Subscripts
struct TimesTable {
	let multiplier: Int

// Instance Subscript
	subscript( index: Int ) -> Int { // Overloading Subscript Operator
		print("TimesTable: subscript Called...")
		return multiplier * index
	}
}

let threeTimesTable = TimesTable( multiplier : 3 )
print( threeTimesTable )
// Using Subscript Operator 
let some = threeTimesTable[ 6 ]  //threeTimesTable.subscript( 6 )
print("Some : ", some )

// Some :  18

//____________________________________________________________________________

// Inbuilt Subscript Operator Usage With Array
let shoppingList = ["Coffee", "Chocolates", "Milk", "Bread", "Eggs", "Apple Watch", "Icecream" ]
print( shoppingList )

// Inbuilt Subscript Operator Usage With Dictionary
var numberOfLegs = ["spider": 8, "ant": 6, "cat": 4]
print( numberOfLegs )
numberOfLegs["bird"] = 2
print( numberOfLegs )


//____________________________________________________________________________

// In C/C++/Java
// int numbers[4][3];
struct Matrix {
	let rows: Int, columns: Int
	var grid: [Double] // 1-Dimentional Data

	init( rows: Int, columns: Int) {
		self.rows = rows
		self.columns = columns
		grid = Array( repeating: 0.0, count: rows * columns )
	}

	func indexIsValid( row: Int, column: Int ) -> Bool {
		return row >= 0 && row < rows && column >= 0 && column < columns
	}

	// Overloading Subscript Operator
	subscript( row: Int, column: Int ) -> Double {
		get {
			assert( indexIsValid( row: row, column: column), "Index Out Of Bound")
			return grid[ row * columns + column ]
		}

		set {
			assert( indexIsValid( row: row, column: column), "Index Out Of Bound")
			grid[ row * columns + column ] = newValue
		}
	}
}

var matrix = Matrix( rows: 3, columns : 3 )
print( matrix )
matrix[0, 1] = 99.99
matrix[1, 0] = 11.11
matrix[2, 2] = 100.100
print( matrix )


// Matrix(rows: 3, columns: 3, grid: [
// 									  0.0, 0.0, 0.0, 
// 									  0.0, 0.0, 0.0, 
// 									  0.0, 0.0, 0.0
// 									 ]
									  
// Matrix(rows: 3, columns: 3, grid: [
// 									 	0.0, 99.99, 0.0, 
// 									  	11.11, 0.0, 0.0, 
// 									  	0.0, 0.0, 100.1
// 									  ]


//____________________________________________________________________________

// Instance Subscripts
// Instance Subscripts, as described above, are subscripts that you call 
// on an instance of a particular type. 

// Type Subscript
// You can also define subscripts that are called on the type itself. 
// This kind of subscript is called a type subscript. 
// You indicate a type subscript by writing the static keyword 
// before the subscript keyword. 
// Classes can use the class keyword instead, to allow subclasses 
// to override the superclass’s implementation of that subscript.


// Creating Type Planet
enum Planet: Int {
    case Mercury = 1, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
    // Type Member i.e. Binded With Type
    static subscript( index: Int ) -> Planet {
    	return Planet( rawValue: index )!
    }
}

let mars = Planet[ 4 ]
print( mars )

let earth = Planet[ 3 ] // Subscript Operator Applied To Type Planet
print( earth )

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

// https://codebunk.com/b/7221100718298/
// https://codebunk.com/b/7221100718298/
// https://codebunk.com/b/7221100718298/

