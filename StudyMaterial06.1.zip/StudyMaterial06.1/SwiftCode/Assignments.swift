//____________________________________________________________________________
//
// DAY 01
//____________________________________________________________________________

ASSIGNMENT A1: REVISE AND PRACTICE SWIFT CODE DONE CLASS

ASSIGNMENT A2: READING ASSINGMENT
		Read Types an Expression Chapter
		The C Programming Language, 2nd Edition
			By Brian Kerngiham and Dennis Ritchie

ASSIGNMENT A3: COMPLETE ALL EXPERIMENTATION ASSIGNMENTS

//____________________________________________________________________________
//
// DAY 02
//____________________________________________________________________________

ASSIGNMENT A1: REVISE AND PRACTICE SWIFT CODE DONE CLASS

ASSIGNMENT A2: READING ASSINGMENT [ MUST MUST MUST ]
		Chapter : Pointers and Arrays
		The C Programming Language, 2nd Edition
			By Brian Kerngiham and Dennis Ritchie

ASSIGNMENT A3: COMPLETE ALL EXPERIMENTATION ASSIGNMENTS

//____________________________________________________________________________
//
// DAY 03
//____________________________________________________________________________

ASSIGNMENT A1: REVISE AND PRACTICE SWIFT CODE DONE CLASS

ASSIGNMENT A2: READING ASSINGMENT [ MUST MUST MUST ]
		Chapter : Pointers and Arrays
		The C Programming Language, 2nd Edition
			By Brian Kerngiham and Dennis Ritchie

ASSIGNMENT A3: COMPLETE ALL EXPERIMENTATION ASSIGNMENTS

//____________________________________________________________________________
//
// DAY 04
//____________________________________________________________________________


ASSIGNMENT A1: REVISE AND PRACTICE SWIFT CODE DONE CLASS

ASSIGNMENT A2: COMPLETE ALL EXPERIMENTATION ASSIGNMENTS

//____________________________________________________________________________
//
// DAY 05
//____________________________________________________________________________

ASSIGNMENT A1: REVISE AND PRACTICE CODE EXAMPLES DONE IN CLASS
ASSIGNMENT A2: COMPLETE ALL EXPERIMENTATION ASSIGNMENTS
ASSIGNMENT A3: READING APPLE DOCUMENTATIONS
	https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html#equals-java.lang.Object-
	https://developer.apple.com/documentation/swift/string
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/basicoperators/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/stringsandcharacters/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/controlflow/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/functions/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/closures/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/enumerations/		
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/classesandstructures/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/properties/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/methods/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/subscripts/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/inheritance/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/initialization/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/deinitialization/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/optionalchaining/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/errorhandling/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/typecasting/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/nestedtypes/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/extensions/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/protocols/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/extensions/


//____________________________________________________________________________
//
// DAY 06
//____________________________________________________________________________

ASSIGNMENT A1: REVISE AND PRACTICE CODE EXAMPLES DONE IN CLASS
ASSIGNMENT A2: COMPLETE ALL EXPERIMENTATION ASSIGNMENTS
ASSIGNMENT A3: READING APPLE DOCUMENTATIONS
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/protocols/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/accesscontrol/#Guiding-Principle-of-Access-Levels
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/advancedoperators/
	
	iOS Apple Guide Reading Assignment
		Read Following Sections From Apple iPhone App Programming Guide

			App Design Basics 13
				Doing Your Initial Design 13
				Learning the Fundamental iOS Design Patterns and Techniques 14 
				Translating Your Initial Design into an Action Plan 14
				Starting the App Creation Process 15
				Best Practices for Maintaining User Privacy 18

			Core App Objects 21
				The Core Objects of Your App 21 
				The Data Model 24

			App States and Multitasking 37 
				Managing App State Changes 38
				The App Launch Cycle 40 
				Responding to Interruptions 47 
				Moving to the Background 49 
				Returning to the Foreground 53 
				App Termination 56
				The Main Run Loop 57

ASSIGNMENT A4: REFACTOR FOLLOWING CODE
	1. Incorporate Good Swift Design Practices
	2. Organise Code Better Way
	3. Apply DRY [ Don't Repeat Yourself ]

	     └── iOSCodeSwift
	         └── ApplicationLifeCycle
	             └── ApplicationLifeCycle3

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

https://github.com/amarjitlife/BajajFinserviOSJune2025
amarjitlife@gmail.com
+91 9980 777 145

//____________________________________________________________________________
//____________________________________________________________________________

