
//____________________________________________________________________________

// Initialization

struct Fahrenheit {
    var temperature: Double

    init() {
        temperature = 32.0
    }
}

var f = Fahrenheit()
print("The default temperature is \(f.temperature)° Fahrenheit")

//____________________________________________________________________________

// Function Overloading
//		1. Based On Number Of Arguments
//		2. Based On Type Of Arguments
//		3. Based On External Parameter Name
//			Because Extenal Parameter Names Are Part Of Function Singatures

func doSomething( some: Int ) { print("Do doSomething :", some ) }
func doSomething( some: Int, someone: Int ) { print("Do doSomething :", some, someone ) }

func doSomething( some: String ) { print("Do doSomething :", some ) }
func doSomething( some: String, someone: String ) { print("Do doSomething :", some, someone ) }

func doSomething( somedance some: String ) { print("Do doSomething :", some ) }
func doSomething( somesing some: String ) { print("Do doSomething :", some ) }

doSomething( some: 99 )
doSomething( some: 99, someone: 88 )

doSomething( some: "Good Morning" )
doSomething( some: "Good Morning", someone: "Gabbar Singh" )

doSomething( somedance: "Hip Hop Dance..." )
doSomething( somesing: "Jazz Sing..." )

//____________________________________________________________________________
// Constructors Are Function With Special Name i.e. init()
//			Contructors Can Also Be Overloaded
//		1. Based On Number Of Arguments
//		2. Based On Type Of Arguments
//		3. Based On External Parameter Name
//			Because Extenal Parameter Names Are Part Of Function Singatures

// Customizing Initialization
// 		Initialization Parameters
//		Overloading Constructors Based On External Parameters Name
//			Because Extenal Parameter Names Are Part Of Function Singatures

struct Celsius {
    var temperatureInCelsius: Double = 0.0

    init(fromFahrenheit fahrenheit: Double) {
        temperatureInCelsius = (fahrenheit - 32) / 1.8
    }

    init(fromKelvin kelvin: Double) {
        temperatureInCelsius = kelvin - 273.15
    }
}

let boilingPointOfWater = Celsius(fromFahrenheit: 212.0)
let freezingPointOfWater = Celsius(fromKelvin: 273.15)
print( boilingPointOfWater )
print( freezingPointOfWater )


//____________________________________________________________________________

// Local and External Parameter Names

struct Color {
    let red, green, blue: Double
    
    init(red: Double, green: Double, blue: Double) {
        self.red   = red
        self.green = green
        self.blue  = blue
    }
    
    init(white: Double) {
        red     = white
        green   = white
        blue    = white
    }
}

let magenta = Color(red: 1.0, green: 0.0, blue: 1.0)
let halfGray = Color(white: 0.5)

// let green = Color( 0.0, 1.0, 0.0 ) // error: missing argument labels 'red:green:blue:' in call
print( magenta )
print( halfGray )


//____________________________________________________________________________

struct Celsius2 {
    var temperatureInCelsius: Double = 0.0

    init(fromFahrenheit fahrenheit: Double) {
        temperatureInCelsius = (fahrenheit - 32) / 1.8
    }

    init(fromKelvin kelvin: Double) {
        temperatureInCelsius = kelvin - 273.15
    }

    //External Parameter Mentioned As _  Hence It Will Not Be Generated
    init(_ celsius: Double) {
        temperatureInCelsius = celsius
    }
}

let bodyTemperature = Celsius2( 37.0 ) // Extenal Parameter Not Required
// let bodyTemperature1 = Celsius2( celsius: 37.0 ) // Extenal Parameter Not Required
// 								// - error: extraneous argument label 'celsius:' in call
print( bodyTemperature )
// print( bodyTemperature1 )

//____________________________________________________________________________

print("\n\nExample: Optional Property Types")
// Optional Property Types

class SurveyQuestion {
    var text: String
    // Optional Properties Are By Default Initialized To nil
    var response: String? // Optional Property

    init(text: String) {
        self.text = text
    }

    func ask() {
        print(text)
    }
}

let cheeseQuestion = SurveyQuestion(text: "Do you like cheese?")
cheeseQuestion.ask()
print( cheeseQuestion.text )
if cheeseQuestion.response == nil { print("Property cheeseQuestion.response is nil")}
cheeseQuestion.response = "Yes, I do like cheese."
print( cheeseQuestion.text )
print("Property \(cheeseQuestion.response!) is nil")

//____________________________________________________________________________

print("\n\nExample: Assigning Constant Properties during Initialization")
// Assigning Constant Properties during Initialization

class SurveyQuestion2 {
    let text: String
    var response: String?

    init(text: String) {
        self.text = text
    }

    func ask() {
        print(text)
    }
}

let beetsQuestion = SurveyQuestion2(text: "How about beets?")
beetsQuestion.ask()

print( beetsQuestion.text )
if beetsQuestion.response == nil { print("Property beetsQuestion.response is nil")}

beetsQuestion.response = "I also like beets. (But not with cheese.)"
print( beetsQuestion.text )
print("Property \(beetsQuestion.response!) is nil")

// beetsQuestion.text = "Trying To Change"


//____________________________________________________________________________

// In Swift
//		For Structures
//		Compiler Will Generate Memeberwise Initialiser/Constructors
//			With All Members As Arguments
struct Resolution {
    var width 	= 0 // Initialised With Default Values
    var height 	= 0
}

// Swift Compiler Will Generate Memeberwise Initialiser/Constructors
let vga = Resolution( width: 640, height: 480 )
print( vga )

let someResolution = Resolution() // Resolution( width: 0, height: 0 )
print( someResolution )

// In Swift
//		For Classes
//		Compiler Will Generate Default Initialiser/Constructors
//			With No Arguments
// Reference Type
class VideoMode {
    var interlaced = false
    var frameRate = 0.0
    var name: String = "Uknown"
}

let someVideoMode = VideoMode()
print( someVideoMode.name )

// Compilation Error For Follwing: As Following Constructor Will Not Be Generated
// let someVideoMode11 = VideoMode(interlaced: true, frameRate: 60, name: "HD" )
// print( someVideoMode1.name )

//____________________________________________________________________________

// Memberwise Initializers for Structure Types
// Because both stored properties have a default value, 
        // the Size structure automatically receives an 
        //      init(width:height:) memberwise initializer, 
        // which you can use to initialize a new Size instance:


struct Size0 {
    var width = 0.0, height = 0.0
}

let twoByTwo = Size0(width: 2.0, height: 2.0)

//____________________________________________________________________________
// Initializer Delegation for Value Types

print("Example: Initializer Delegation for Value Types")


struct Size {
    var width = 0.0, height = 0.0
}

struct Point {
    var x = 0.0, y = 0.0
}

struct Rect {
    var origin = Point()
    var size = Size()

    init() {}

    // Constructor Defined By Programmer : Hence Compiler Will Not Generate It
    init(origin: Point, size: Size) {
        self.origin = origin
        self.size = size
    }

    init(center: Point, size: Size) {
        let originX = center.x - (size.width / 2)
        let originY = center.y - (size.height / 2)
        self.init(origin: Point(x: originX, y: originY), size: size)
    }
}

let basicRect = Rect()
print( basicRect )

let originRect = Rect(origin: Point(x: 2.0, y: 2.0), 
    size: Size(width: 5.0, height: 5.0))
print( originRect )

let centerRect = Rect(center: Point(x: 4.0, y: 4.0), 
    size: Size(width: 3.0, height: 3.0))
print( centerRect )


//____________________________________________________________________________

print("Example : Designated and Convenience Initializers in Action")

// Designated and Convenience Initializers in Action
//		1. All Convenince Constructors Within Class Should Designated Constructor From Same Class
//		2. All Designated Constructors From Child Class Should Call Parent Designated Constructor
class Food {
    var name: String

	// Designated Initialiser/Constructor
	//		Which Initiliases Object Completely
    init(name: String) {
    	// All Initialisation Logic At One Place
        self.name = name
    }

	// Convenience Initialiser/Constructor        
    convenience init() {
    	// Convenince Initialiser Calling Designated Initialer Within Class
        self.init(name: "[Unnamed]")
    }
}

let namedMeat = Food(name: "Bacon")
let mysteryMeat = Food()

class RecipeIngredient: Food {
    var quantity: Int

	// Designated Initialiser/Constructor        
    init(name: String, quantity: Int) {
        self.quantity = quantity
		// Designated Initialiser Calling Designated From Parent Class
        super.init(name: name)
    }

	// Convenience Initialiser/Constructor        
    override convenience init(name: String) {
    	// Convenince Initialiser Calling Designated Initialer Within Class
        self.init(name: name, quantity: 1)
    }
}

let oneMysteryItem = RecipeIngredient()
let oneBacon = RecipeIngredient(name: "Bacon")
let sixEggs = RecipeIngredient(name: "Eggs", quantity: 6)

//____________________________________________________________________________

// Failable Initializers


struct Animal {
    let species: String

// Failable Initializers   
    init?(species: String) {
        if species.isEmpty { return nil }
        self.species = species
    }
}

if let someCreature = Animal(species: "Giraffe") {
	print( someCreature )
} else {
	print("Nothingness Found")
}

//____________________________________________________________________________

// Failable Initializers for Enumerations


enum TemperatureUnit {
    case Kelvin, Celsius, Fahrenheit

    init?(symbol: Character) {
        switch symbol {
        case "K":
            self = .Kelvin
        case "C":
            self = .Celsius
        case "F":
            self = .Fahrenheit
        default:
            return nil
        }
    }
}

let fahrenheitUnit = TemperatureUnit(symbol: "F")
if fahrenheitUnit != nil {
    print("This is a defined temperature unit, so initialization succeeded.")
}

let unknownUnit = TemperatureUnit(symbol: "X")
if unknownUnit == nil {
    print("This is not a defined temperature unit, so initialization failed.")
}

//____________________________________________________________________________

// Failable Initializers for Classes
// Failable initializers for value types can trigger failure at any point. 
// For classes, however a failable initializer can trigger an initialization failure 
//      Only after all stored properties introduced by that class have been 
//      set to an initial value.

class Product {
    let name: String!

    init?(name: String) {
        self.name = name
        if name.isEmpty { return nil }
    }
}

// Propagation of Initialization Failure
class CartItem: Product {
    let quantity: Int!

    init?(name: String, quantity: Int) {
        self.quantity = quantity
        super.init(name: name)
        if quantity < 1 { return nil }
    }
}

if let bowTie = Product(name: "bow tie") {
    // no need to check if bowTie.name == nil
    print("The product's name is \(bowTie.name)")
}

if let twoSocks = CartItem(name: "sock", quantity: 2) {
    print("Item: \(twoSocks.name), quantity: \(twoSocks.quantity)")
}

if let zeroShirts = CartItem(name: "shirt", quantity: 0) {
    print("Item: \(zeroShirts.name), quantity: \(zeroShirts.quantity)")
} else {
    print("Unable to initialize zero shirts")
}

if let oneUnnamed = CartItem(name: "", quantity: 1) {
    print("Item: \(oneUnnamed.name), quantity: \(oneUnnamed.quantity)")
} else {
    print("Unable to initialize one unnamed product")
}

//____________________________________________________________________________

// Overriding a Failable Initializer

class Document {
    var name: String?

    // this initializer creates a document with a nil name value
    init() {}

    // this initializer creates a document with a non-empty name value
    init?(name: String) {
        self.name = name
        if name.isEmpty { return nil }
    }
}

class AutomaticallyNamedDocument: Document {
    override init() {
        super.init()
        self.name = "[Untitled]"
    }

    override init(name: String) {
        super.init()
        if name.isEmpty {
            self.name = "[Untitled]"
        } else {
            self.name = name
        }
    }
}

//____________________________________________________________________________

class Player {
    var coinsInPurse: Int
    
    init(coins: Int) { // Constructor
    	print("Player: Init Called...")
        coinsInPurse = coins
    }
    
    func winCoins(coins: Int) {
        coinsInPurse += coins
    }
    
    deinit { // Destructor
    	print("Player: DeInit Called...")
    }
}

var playerOne: Player? = Player(coins: 100)
print( playerOne?.coinsInPurse )
playerOne = nil

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________


// https://codebunk.com/b/4461100718427/
// https://codebunk.com/b/4461100718427/
// https://codebunk.com/b/4461100718427/

