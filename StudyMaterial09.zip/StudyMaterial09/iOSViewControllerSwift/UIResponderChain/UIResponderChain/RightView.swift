//
//  RightView.swift
//  UIResponderChain
//
//  Created by Nagarajan on 8/28/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class RightView: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        // Initialization code
      
        let singleTap = UITapGestureRecognizer(
            target: self,
            action: #selector(RightView.handleSingleTapGesture(_:))
        )
        singleTap.numberOfTapsRequired = 1
        singleTap.numberOfTouchesRequired = 1
        self.addGestureRecognizer(singleTap)

        let doubleTap = UITapGestureRecognizer(
            target: self,
            action: #selector(RightView.handleDoubleTapGesture(_:))
        )
        doubleTap.numberOfTapsRequired = 2
        doubleTap.numberOfTouchesRequired = 1
        self.addGestureRecognizer(doubleTap)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect)
    {
        // Drawing code
    }
    */
    @objc func handleSingleTapGesture(_ recognizer: UITapGestureRecognizer) {
        if(recognizer.state == UIGestureRecognizer.State.ended) {
            let alertView = UIAlertView(title: "SingleTap At RightView",
                message: "RightView Responder",
                delegate: nil,
                cancelButtonTitle: "OK")
            alertView.show()
        }
    }

    @objc func handleDoubleTapGesture(_ recognizer: UITapGestureRecognizer)
    {
        if(recognizer.state == UIGestureRecognizer.State.ended)
        {
            let alertView = UIAlertView(title: "Double Tap At RightView",
                message: "RightView Responder",
                delegate: nil,
                cancelButtonTitle: "OK")
            alertView.show()
        }
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
         print("RightView: Function \(#function) Called...")
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        print("RightView: Function \(#function) Called...")
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        print("RightView: Function \(#function) Called...")
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        print("RightView: Function \(#function) Called...")
    }

}
