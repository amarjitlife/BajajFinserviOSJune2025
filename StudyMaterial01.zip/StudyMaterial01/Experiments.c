
#include <stdio.h>

//____________________________________________________________________________

void playWithTypesValues() {
	// let twoThousand: UInt16 = 2_000
	// let one: UInt8 = 1

	unsigned short twoThousand = 2000;
	unsigned char one = 1;

	// let twoThousandAndOne = twoThousand + one 
	unsigned short twoThousandAndOne = twoThousand + one;
	printf( "\nValue: %d", twoThousandAndOne );

	unsigned short maxValue = 65535;
	unsigned short maxValueAndOne = maxValue + one;
	printf( "\nValue: %d", maxValueAndOne );
}

//____________________________________________________________________________

void playWithIf() {

	int i = -10;

	if ( i ) {
		printf("\nValue: %d", i );
	} else {
		printf("\nSomething Else ...");
	}

}

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

int main() {
	printf("\n\nFunction : playWithTypesValues");
	playWithTypesValues();

	printf("\n\nFunction : playWithIf");
	playWithIf();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
}
