
//____________________________________________________________________________

var names = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]

func backwards(s1: String, s2: String) -> Bool {
    return s1 > s2
}

print( names )
names.sort(by: backwards)
print( names )

//____________________________________________________________________________

names.sort(by: { (s1: String, s2: String) -> Bool in return s1 > s2 }  )
print( names )
names.sort(by: { s1, s2 in return s1 > s2 }  )
print( names )

// names.sorted(by: { s1, s2 in return s1 > s2 } )

names.sort(by: { s1, s2 in s1 > s2 }  )
names.sort(by: { $0 > $1 }  )
names.sort(by: > )

//____________________________________________________________________________

func saySomething() {
	print("Good Morning!")
}

let some: () = saySomething()
print( some )

//____________________________________________________________________________

// let digitNames: [Int : String] = [0: "Zero", 1: "One", 2: "Two", 3: "Three", 4:"Four", 
	              // 5: "Five", 6:"Six", 7: "Seven", 8: "Eight", 9: "Nine"]

let digitNames = [0: "Zero", 1: "One", 2: "Two", 3: "Three", 4:"Four", 
	              5: "Five", 6:"Six", 7: "Seven", 8: "Eight", 9: "Nine"]

let numbers = [ 16, 58, 510 ]
let strings = numbers.map( {
	( number ) -> String in
	var number = number
	var output = ""
	while number > 0 {
		output = digitNames[ number % 10 ]! + output
		number /= 10
	}
	return output
})

print( strings )

//____________________________________________________________________________

func numbersToWords( numbers: [Int] ) -> [String] {
	let strings = numbers.map { /// Trailing Lambda Syntax
		( number ) -> String in
		var number = number
		var output = ""
		while number > 0 {
			output = digitNames[ number % 10 ]! + output
			number /= 10
		}
		return output
	} // })
	return strings
}

print( numbersToWords( numbers: numbers ) )

//____________________________________________________________________________

func makeIncrementor( forIncrement amount: Int ) -> () -> Int {
	var runningTotal = 0
	func incrementor() -> Int {
		runningTotal += amount
		return runningTotal
	}

	return incrementor
}

let incrementByTen = makeIncrementor( forIncrement: 10 )
var result: Int
result = incrementByTen()
print( result )
result = incrementByTen()
print( result )
result = incrementByTen()
print( result )

let incrementBySeven = makeIncrementor( forIncrement: 7 )
result = incrementBySeven()
print( result )
result = incrementBySeven()
print( result )
result = incrementBySeven()
print( result )

// In Swift
// Closures Are Reference Types In Swift
let incrementByTenAgain = incrementByTen // Reference Assignment
result = incrementByTenAgain()
print( result )
result = incrementByTen()
print( result )


//____________________________________________________________________________

var numbers1 = [10, 20, 30, 40, 50]

// In Swift
// Arrays Are Value Type
var numers1Again = numbers1 // Value Assignment

print( numbers1 )
print( numers1Again )

numbers1[0] = 99
print( numbers1 )
print( numers1Again )

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

