
//____________________________________________________________________________


enum CompassPoint {
    case North
    case South
    case East
    case West
}

enum Planet {
    case Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
}

// var directionToHead: CompassPoint = CompassPoint.West
// Inferred and Binded Type CompassPoint
var directionToHead = CompassPoint.West

directionToHead = .East

switch directionToHead {
case .North:
    print("Lots of planets have a north")
case .South:
    print("Watch out for penguins")
case .East:
    print("Where the sun rises")
case .West:
    print("Where the skies are blue")
}

directionToHead = .South
switch directionToHead {
case .North:
    print("Lots of planets have a north")
case .South:
    print("Watch out for penguins")
case .East:
    print("Where the sun rises")
// case .West:
//     print("Where the skies are blue")
default:
	print("Something Happened... I don't Know What?")
}

//____________________________________________________________________________

// Associated Values

enum Barcode {
    case UPCA(Int, Int, Int)
    case QRCode(String)
}
var productBarcode = Barcode.UPCA(8, 85909_51226, 3)
productBarcode = .QRCode("ABCDEFGHIJKLMNOP")

switch productBarcode {
case .UPCA(let numberSystem, let identifier, let check):
    print("UPC-A with value of \(numberSystem), \(identifier), \(check)")
case .QRCode(let productCode):
    print("QR code with value of \(productCode).")
}

productBarcode = Barcode.UPCA(8, 85909_51226, 3)
switch productBarcode {
case let .UPCA(numberSystem, identifier, check):
    print("UPC-A with value of \(numberSystem), \(identifier), \(check)")
case let .QRCode(productCode):
    print("QR code with value of \(productCode).")
}

//____________________________________________________________________________

// Raw Values

enum ASCIIControlCharacter: Character {
    case Tab = "\t"
    case LineFeed = "\n"
    case CarriageReturn = "\r"
}

// Implicitly Assigned Raw Values

enum PlanetRaw: Int {
    case Mercury = 1, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
}

print( PlanetRaw.Mercury )
print( PlanetRaw.Mercury.rawValue )

enum CompassPointRaw: String {
    case North, South, East, West
}

print( CompassPointRaw.North )
print( CompassPointRaw.West )

let sunsetDirection = CompassPointRaw.West.rawValue
print( sunsetDirection )

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________


// https://codebunk.com/b/7221100718298/
// https://codebunk.com/b/7221100718298/
// https://codebunk.com/b/7221100718298/
