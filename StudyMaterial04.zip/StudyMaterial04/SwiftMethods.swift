
//____________________________________________________________________________

// Methods
// 	Instance Methods

class Counter {
    var count = 0
    
    func increment() {
        count = count + 1
    }
    
    func incrementBy(amount: Int) {
        count += amount
    }
    
    func reset() {
        count = 0
    }
}

let counter = Counter()
counter.increment()
counter.incrementBy(amount: 5)
counter.reset()

//____________________________________________________________________________

// amount is a local name only.
// numberOfTimes is both a local and external name

class CounterTwo {
    var count: Int = 0

    func incrementBy(amount: Int, numberOfTimes: Int) {
        count += amount * numberOfTimes
    }
}

let counter2 = CounterTwo()
counter2.incrementBy(amount: 5, numberOfTimes:3)

//____________________________________________________________________________

//  You don’t need to define an external parameter name for the first argument value, 
        // because its purpose is clear from the function name incrementBy. 
        // The second argument, however, is qualified by an external parameter name 
                // to make its purpose clear when the method is called.

// The self Property
// Every instance of a type has an implicit property called self, i
        // which is exactly equivalent to the instance itself. 
        // Use this implicit self property to refer to the current instance within 
        // its own instance methods.


struct Point {
    var x = 0.0, y = 0.0

    func isToTheRightOfX(x: Double) -> Bool {
        return self.x > x
    }

    mutating func moveByX( deltaX: Double, deltaY: Double ) {
    	self.x += deltaX
    	self.y += deltaY
    }
}

var somePoint = Point(x: 4.0, y: 5.0)

if somePoint.isToTheRightOfX(x: 1.0) {
    print("This point is to the right of the line where x == 1.0")
}

print( somePoint )
somePoint.moveByX( deltaX: 10.0, deltaY: 10.0 )
print( somePoint )


//____________________________________________________________________________

// Mutating methods for enumerations can set the implicit self parameter 
// to be a different member from the same enumeration:

enum TriStateSwitch {
    case Off, Low, High
    mutating func next() {
        switch self {
        case .Off:
            self = .Low
        case .Low:
            self = .High
        case .High:
            self = .Off
        }
    }
}
var ovenLight = TriStateSwitch.Low
print( ovenLight )
ovenLight.next()
print( ovenLight )

ovenLight.next()
print( ovenLight )

//____________________________________________________________________________

struct LevelTracker {
    static var highestUnlockedLevel = 1

    static func unlockLevel(level: Int) {
        if level > highestUnlockedLevel { highestUnlockedLevel = level }
    }

    static func levelIsUnlocked(level: Int) -> Bool {
        return level <= highestUnlockedLevel
    }

    var currentLevel = 1
    mutating func advanceToLevel(level: Int) -> Bool {
        if LevelTracker.levelIsUnlocked(level: level) {
            currentLevel = level
            return true
        } else {
            return false
        }
    }
}

class Player {
    var tracker = LevelTracker()
    let playerName: String

    func completedLevel(level: Int) {
        LevelTracker.unlockLevel(level: level + 1)
        tracker.advanceToLevel(level: level + 1)
    }

    init(name: String) {
        playerName = name
    }
}

var player = Player(name: "Argyrios")
player.completedLevel(level: 1)
print("highest unlocked level is now \(LevelTracker.highestUnlockedLevel)")

player = Player(name: "Beto")
if player.tracker.advanceToLevel(level: 6) {
    print("player is now on level 6")
} else {
    print("level 6 has not yet been unlocked")
}

// HOME WORK
// HOME WORK
// HOME WORK

// REFACTOR ABOVE CODE TO DO BETTER DESIGN

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

// https://codebunk.com/b/7221100718298/
// https://codebunk.com/b/7221100718298/
// https://codebunk.com/b/7221100718298/

